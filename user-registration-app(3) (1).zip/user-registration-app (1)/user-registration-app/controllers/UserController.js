// controllers/UserController.js
const User = require('../models/User');

exports.registerForm = (req, res) => {
  res.sendFile(__dirname + '/views/register.html');
};

exports.register = async (req, res) => {
  try {
    const user = new User(req.body);
    await user.save();
    res.send('User registered successfully');
  } catch (err) {
    res.status(400).send('Error registering user');
  }
};
