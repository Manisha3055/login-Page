// routes.js
const express = require('express');
const router = express.Router();
const UserController = require('./controllers/UserController');

// Route for user registration form
router.get('/register', UserController.registerForm);

// Route for handling user registration
router.post('/register', UserController.register);

module.exports = router;
